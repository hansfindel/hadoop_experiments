#!/bin/sh

javac -cp .:/user/grima/hadoop-2.4.0/share/hadoop/common/hadoop-common-2.4.0.jar:/user/grima/hadoop-2.4.0/share/hadoop/mapreduce/hadoop-mapreduce-client-core-2.4.0.jar:/user/grima/hadoop-2.4.0/share/hadoop/mapreduce/hadoop-mapreduce-client-common-2.4.0.jar:/user/grima/hadoop-2.4.0/share/hadoop/common/lib/hadoop-annotations-2.4.0.jar WordCount.java 

